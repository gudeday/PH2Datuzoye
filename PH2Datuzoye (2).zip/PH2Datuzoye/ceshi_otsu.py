import os
import cv2
import numpy as np
from PIL import Image
from tqdm import tqdm
import csv

class OtsuThresholdSegmentation:
    """使用 Otsu 方法进行二值分割"""
    def __init__(self):
        pass

    def predict(self, image):
        """
        生成二值掩码
        Args:
            image: PIL Image 或 numpy array
        Returns:
            mask: numpy array (H x W), 0/1
        """
        if isinstance(image, Image.Image):
            image = np.array(image)

        if len(image.shape) == 3 and image.shape[2] == 3:  # HWC RGB
            image = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        elif len(image.shape) == 3 and image.shape[0] == 3:  # CHW
            image = cv2.cvtColor(image.transpose(1,2,0), cv2.COLOR_RGB2GRAY)

        # Otsu 阈值
        _, mask = cv2.threshold(image.astype(np.uint8), 0, 1, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        return mask

def compute_metrics(pred_mask, gt_mask):
    """计算二值掩码指标"""
    pred_flat = pred_mask.flatten()
    gt_flat = gt_mask.flatten()

    TP = np.sum(pred_flat * gt_flat)
    TN = np.sum((1 - pred_flat) * (1 - gt_flat))
    FP = np.sum(pred_flat * (1 - gt_flat))
    FN = np.sum((1 - pred_flat) * gt_flat)

    dice = (2 * TP) / (2 * TP + FP + FN + 1e-8)
    iou = TP / (TP + FP + FN + 1e-8)
    acc = (TP + TN) / (TP + TN + FP + FN + 1e-8)
    precision = TP / (TP + FP + 1e-8)
    recall = TP / (TP + FN + 1e-8)
    specificity = TN / (TN + FP + 1e-8)

    return dice, iou, acc, precision, recall, specificity

def evaluate_folder(image_dir, mask_dir):
    """评估文件夹中所有图片"""
    files = sorted(os.listdir(image_dir))
    dice_all, iou_all, acc_all, precision_all, recall_all, specificity_all = [], [], [], [], [], []

    segmenter = OtsuThresholdSegmentation()

    for f in tqdm(files):
        image_path = os.path.join(image_dir, f)

        # 自动生成掩码名称
        name, ext = os.path.splitext(f)
        mask_name = f"{name}_lesion{ext}"
        mask_path = os.path.join(mask_dir, mask_name)

        if not os.path.exists(mask_path):
            print(f"Mask not found for {f}, skipping.")
            continue

        image = Image.open(image_path)
        mask_gt = np.array(Image.open(mask_path))
        mask_gt = (mask_gt > 0).astype(np.uint8)  # 确保二值化

        mask_pred = segmenter.predict(image)

        dice, iou, acc, precision, recall, specificity = compute_metrics(mask_pred, mask_gt)

        dice_all.append(dice)
        iou_all.append(iou)
        acc_all.append(acc)
        precision_all.append(precision)
        recall_all.append(recall)
        specificity_all.append(specificity)

    metrics = {
        "Dice": np.mean(dice_all),
        "IoU": np.mean(iou_all),
        "Accuracy": np.mean(acc_all),
        "Precision": np.mean(precision_all),
        "Recall": np.mean(recall_all),
        "Specificity": np.mean(specificity_all)
    }

    # 保存指标到 CSV

    return metrics

if __name__ == "__main__":
    # 文件夹路径
    image_folder = "./datas/testx"       # 原图文件夹
    mask_folder = "./datas/testy"        # 真实掩码文件夹

    metrics = evaluate_folder(image_folder, mask_folder)
    print("===== Otsu 阈值分割评估指标 =====")
    for k, v in metrics.items():
        print(f"{k}: {v:.4f}")
