import os
import yaml
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm

import matplotlib.pyplot as plt

import random
import numpy as np
# 导入自定义 Dataset 和 U-Net
from datas.Datasets import SkinDataset
from models.Unetmodel import U_Net





def set_seed(seed=42):
    random.seed(seed)                     # Python 随机种子
    np.random.seed(seed)                  # Numpy 随机种子
    torch.manual_seed(seed)               # PyTorch CPU 随机种子
    torch.cuda.manual_seed(seed)          # PyTorch GPU 随机种子
    torch.cuda.manual_seed_all(seed)      # 多 GPU
    torch.backends.cudnn.deterministic = True   # 固定卷积算法
    torch.backends.cudnn.benchmark = False      # 禁止动态优化算法

# -------------------------------
# 读取 YAML 配置
# -------------------------------
with open("config1.yaml", "r") as f:
    config = yaml.safe_load(f)

# 数据集参数
dataset_cfg = config['dataset']
root_dir = dataset_cfg['root_dir']
img_size = dataset_cfg['img_size']

# 训练参数
train_cfg = config['training']
batch_size = train_cfg['batch_size']
num_epochs = train_cfg['num_epochs']
learning_rate = train_cfg['learning_rate']
num_workers = train_cfg['num_workers']
save_dir = train_cfg['save_dir']
patience = train_cfg.get('patience', 10)  # 早停策略默认 patience=10
seed = train_cfg['seed']
BCEa = train_cfg['BCEa']
DCEa = train_cfg['DCEa']

# 模型参数
model_cfg = config['model']
in_channels = model_cfg['in_channels']
out_channels = model_cfg['out_channels']

# -------------------------------
# 数据集与 DataLoader
# -------------------------------
train_dataset = SkinDataset(root=root_dir, train=True, img_size=img_size)
test_dataset = SkinDataset(root=root_dir, train=False, img_size=img_size)

train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=num_workers)
test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False)

# -------------------------------
# 模型、优化器、损失函数
# -------------------------------
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = U_Net(in_channels, out_channels).to(device)
optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
bce_loss = nn.BCELoss()

# Dice Loss
def dice_loss(pred, target, smooth=1.):
    pred = pred.view(-1)
    target = target.view(-1)
    intersection = (pred * target).sum()
    return 1 - (2. * intersection + smooth) / (pred.sum() + target.sum() + smooth)

# 组合损失
def combined_loss(pred, target):
    return BCEa * bce_loss(pred, target) + DCEa * dice_loss(pred, target)

# -------------------------------
# 训练和验证函数
# -------------------------------
def train_one_epoch(model, loader, optimizer):
    model.train()
    epoch_loss = 0
    for images, masks in tqdm(loader, desc="Training"):
        images, masks = images.to(device), masks.to(device)

        preds = model(images)
        preds = torch.sigmoid(preds)

        loss = combined_loss(preds, masks)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        epoch_loss += loss.item()
    return epoch_loss / len(loader)

def validate(model, loader):
    model.eval()
    dice_score = 0
    with torch.no_grad():
        for images, masks in loader:
            images, masks = images.to(device), masks.to(device)
            preds = model(images)
            preds = torch.sigmoid(preds)
            preds_bin = (preds > 0.5).float()
            intersection = (preds_bin * masks).sum()
            dice = (2. * intersection) / (preds_bin.sum() + masks.sum() + 1e-8)
            dice_score += dice.item()
    return dice_score / len(loader)

# -------------------------------
# 主训练循环（带早停）
# -------------------------------
if __name__ == '__main__':
    os.makedirs(save_dir, exist_ok=True)
    best_dice = 0
    trigger_times = 0  # 计数早停触发
    set_seed(seed)
    lossall = []
    loss_save_dir = "./model/loss"  # 可根据需要修改
    os.makedirs(loss_save_dir, exist_ok=True)
    save_path = os.path.join(loss_save_dir, "loss_config1.png")

    for epoch in range(num_epochs):
            print(f"\nEpoch {epoch+1}/{num_epochs}")

            train_loss = train_one_epoch(model, train_loader, optimizer)
            lossall.append(train_loss) #保存每一步的loss
            val_dice = validate(model, test_loader)

            print(f"Train Loss: {train_loss:.4f} | Validation Dice: {val_dice:.4f}")

            # 保存最佳模型
            if val_dice > best_dice:
                best_dice = val_dice
                trigger_times = 0
                torch.save(model.state_dict(), os.path.join(save_dir, 'best_model.pth'))
                print("Saved Best Model!")
            else:
                trigger_times += 1
                print(f"No improvement for {trigger_times} epoch(s)")

            # 早停判定
            if trigger_times >= patience:
                print(f"Early stopping triggered. Best Validation Dice: {best_dice:.4f}")
                break
    plt.figure(figsize=(8, 5))
    plt.plot(range(1, len(lossall) + 1), lossall, 'b-o', label='Train Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training Loss Curve')
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    # 保存图像，不显示
    plt.savefig(save_path, dpi=300)
    plt.close()
    print("Training finished!")
