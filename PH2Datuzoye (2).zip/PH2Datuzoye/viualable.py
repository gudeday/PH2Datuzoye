import os
import cv2
import torch
import numpy as np
from PIL import Image
from tqdm import tqdm
from models.Unetmodel import U_Net

def predict_mask(model, image, device, input_size=512):
    """
    对单张图像生成预测掩码并恢复原始尺寸
    """
    orig_w, orig_h = image.size

    # 灰度化
    image_gray = image.convert("L")  # PIL 灰度图
    # resize
    image_resized = image_gray.resize((input_size, input_size))
    img_np = np.array(image_resized).astype(np.float32) / 255.0
    img_np = np.expand_dims(img_np, axis=0)  # C,H,W
    img_tensor = torch.tensor(img_np).unsqueeze(0).to(device)  # 1,C,H,W

    model.eval()
    with torch.no_grad():
        pred = model(img_tensor)
        pred = torch.sigmoid(pred)
        pred_mask = (pred > 0.5).float().cpu().squeeze().numpy()  # 512x512

    # 恢复原始尺寸
    mask_pred_resized = cv2.resize(pred_mask, (orig_w, orig_h), interpolation=cv2.INTER_NEAREST)
    mask_pred_resized = (mask_pred_resized > 0.5).astype(np.uint8)
    return mask_pred_resized

def visualize_prediction(image, mask_pred, mask_gt=None, save_path=None):
    """
    将预测掩码叠加在原图上进行可视化，可选显示真实掩码
    """
    image_np = np.array(image.convert("RGB"))
    overlay = image_np.copy()

    # 预测掩码 红色
    mask_pred_rgb = np.zeros_like(image_np)
    mask_pred_rgb[:, :, 0] = mask_pred * 255  # 红色

    overlay = cv2.addWeighted(overlay, 0.7, mask_pred_rgb, 0.3, 0)

    # 如果提供真实掩码，则叠加蓝色显示真实掩码
    if mask_gt is not None:
        mask_gt_rgb = np.zeros_like(image_np)
        mask_gt_rgb[:, :, 2] = mask_gt * 255  # 蓝色
        overlay = cv2.addWeighted(overlay, 0.8, mask_gt_rgb, 0.2, 0)

    if save_path:
        Image.fromarray(overlay).save(save_path)
    return overlay

if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model_path = "./model/results/best_model_512p.pth"
    image_folder = "./datas/testx"
    mask_folder = "./datas/testy"  # 真实掩码文件夹
    output_vis_folder = "./datas/pred_overlay"
    output_mask_folder = "./datas/pred_mask"
    os.makedirs(output_vis_folder, exist_ok=True)
    os.makedirs(output_mask_folder, exist_ok=True)

    # 加载模型
    model = U_Net(1,1).to(device)
    model.load_state_dict(torch.load(model_path, map_location=device))

    files = sorted(os.listdir(image_folder))
    for f in tqdm(files):
        image_path = os.path.join(image_folder, f)
        mask_path = os.path.join(mask_folder, f.replace(".bmp","_lesion.bmp"))

        image = Image.open(image_path)
        mask_gt = np.array(Image.open(mask_path))
        mask_gt = (mask_gt > 0).astype(np.uint8)

        # 预测掩码
        mask_pred = predict_mask(model, image, device, input_size=512)

        # 保存预测二值掩码
        mask_save_path = os.path.join(output_mask_folder, f.replace(".bmp","_pred_mask.bmp"))
        Image.fromarray((mask_pred*255).astype(np.uint8)).save(mask_save_path)

        # 保存真实掩码（原始尺寸）
        real_mask_save_path = os.path.join(output_mask_folder, f.replace(".bmp","_gt_mask.bmp"))
        Image.fromarray((mask_gt*255).astype(np.uint8)).save(real_mask_save_path)

        # 保存可视化叠加（红色预测 + 蓝色真实掩码）
        overlay_save_path = os.path.join(output_vis_folder, f)
        visualize_prediction(image, mask_pred, mask_gt=mask_gt, save_path=overlay_save_path)
