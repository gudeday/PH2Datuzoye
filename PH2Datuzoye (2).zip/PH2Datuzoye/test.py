import os
import torch
from models.Unetmodel import U_Net
from datas.Datasets import SkinDataset
from torch.utils.data import DataLoader

def evaluate_segmentation(model, dataloader, device):
    """
    对二值分割模型进行评估
    Args:
        model: 训练好的模型
        dataloader: 测试集 DataLoader
        device: 'cuda' 或 'cpu'
    Returns:
        metrics: dict，包含 Dice, IoU, Accuracy, Precision, Recall, Specificity
    """
    model.eval()

    dice_all, iou_all, acc_all, precision_all, recall_all, specificity_all = [], [], [], [], [], []

    with torch.no_grad():
        for images, masks in dataloader:
            images, masks = images.to(device), masks.to(device)

            preds = model(images)
            preds = torch.sigmoid(preds)
            preds_bin = (preds > 0.5).float()  # 二值化

            # Flatten
            preds_flat = preds_bin.view(-1)
            masks_flat = masks.view(-1)

            TP = (preds_flat * masks_flat).sum()
            TN = ((1 - preds_flat) * (1 - masks_flat)).sum()
            FP = (preds_flat * (1 - masks_flat)).sum()
            FN = ((1 - preds_flat) * masks_flat).sum()

            dice = (2 * TP) / (2 * TP + FP + FN + 1e-8)
            iou = TP / (TP + FP + FN + 1e-8)
            acc = (TP + TN) / (TP + TN + FP + FN + 1e-8)
            precision = TP / (TP + FP + 1e-8)
            recall = TP / (TP + FN + 1e-8)
            specificity = TN / (TN + FP + 1e-8)

            dice_all.append(dice.item())
            iou_all.append(iou.item())
            acc_all.append(acc.item())
            precision_all.append(precision.item())
            recall_all.append(recall.item())
            specificity_all.append(specificity.item())

    metrics = {
        "Dice": sum(dice_all)/len(dice_all),
        "IoU": sum(iou_all)/len(iou_all),
        "Accuracy": sum(acc_all)/len(acc_all),
        "Precision": sum(precision_all)/len(precision_all),
        "Recall": sum(recall_all)/len(recall_all),
        "Specificity": sum(specificity_all)/len(specificity_all)
    }
    return metrics


if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    rootpath = "./model/results"
    model_512_path = os.path.join(rootpath, "best_model_512p.pth")
    model_256_path = os.path.join(rootpath, "best_model_256p.pth")

    # 创建模型实例
    model_512 = U_Net(1, 1).to(device)
    model_256 = U_Net(1, 1).to(device)

    # 加载权重
    model_512.load_state_dict(torch.load(model_512_path, map_location=device))
    model_256.load_state_dict(torch.load(model_256_path, map_location=device))

    # ---------------------------
    # 加载对应尺寸的测试集
    # ---------------------------
    test_dataset_512 = SkinDataset(root="./datas", train=False, img_size=512)
    test_dataset_256 = SkinDataset(root="./datas", train=False, img_size=256)

    test_loader_512 = DataLoader(test_dataset_512, batch_size=1, shuffle=False)
    test_loader_256 = DataLoader(test_dataset_256, batch_size=1, shuffle=False)

    # ---------------------------
    # 分别评估
    # ---------------------------
    metrics_512 = evaluate_segmentation(model_512, test_loader_512, device)
    metrics_256 = evaluate_segmentation(model_256, test_loader_256, device)

    print("===== 512x512 模型评估指标 =====")
    for k, v in metrics_512.items():
        print(f"{k}: {v:.4f}")

    print("\n===== 256x256 模型评估指标 =====")
    for k, v in metrics_256.items():
        print(f"{k}: {v:.4f}")
