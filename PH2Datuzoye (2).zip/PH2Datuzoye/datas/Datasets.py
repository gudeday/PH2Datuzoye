import torch
from torch.utils.data import Dataset
from PIL import Image
from torchvision import transforms
import os
import random

class SkinDataset(Dataset):
    def __init__(self, root, train=True, img_size=256):
        self.root = root
        self.train = train
        self.img_size = img_size  # 目标尺寸

        # 数据路径
        data_dir = 'new_trainx' if train else 'testx'
        mask_dir = 'new_trainy' if train else 'testy'
        self.img_dir = os.path.join(root, data_dir)
        self.mask_dir = os.path.join(root, mask_dir)

        # 获取图像列表并排序
        self.img_names = sorted(os.listdir(self.img_dir))
        self.mask_names = sorted(os.listdir(self.mask_dir))
        assert len(self.img_names) == len(self.mask_names), "图像和掩码数量不一致"

        # 基础 transform：调整大小 + 转为单通道 Tensor
        self.img_transform = transforms.Compose([
            transforms.Resize((img_size, img_size)),
            transforms.Grayscale(num_output_channels=1),
            transforms.ToTensor()
        ])
        self.mask_transform = transforms.Compose([
            transforms.Resize((img_size, img_size)),
            transforms.ToTensor()
        ])

    def __len__(self):
        return len(self.img_names)

    def __getitem__(self, idx):
        # 读取图像和掩码
        img_path = os.path.join(self.img_dir, self.img_names[idx])
        mask_path = os.path.join(self.mask_dir, self.mask_names[idx])
        image = Image.open(img_path).convert('RGB')
        mask = Image.open(mask_path).convert('L')  # 灰度图

        # 数据增强（仅训练集使用）
        if self.train:
            # 随机水平翻转
            if random.random() > 0.5:
                image = transforms.functional.hflip(image)
                mask = transforms.functional.hflip(mask)
            # 随机垂直翻转
            if random.random() > 0.5:
                image = transforms.functional.vflip(image)
                mask = transforms.functional.vflip(mask)
            # 随机旋转 [-30, 30] 度
            angle = random.uniform(-30, 30)
            image = transforms.functional.rotate(image, angle, fill=0)
            mask = transforms.functional.rotate(mask, angle, fill=0)

        # 转为 Tensor 并归一化
        image = self.img_transform(image)
        mask = self.mask_transform(mask)
        mask = (mask > 0.5).float()  # 二值化 mask

        return image, mask
