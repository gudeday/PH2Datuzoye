import os
import shutil
import random
from pathlib import Path

def split_dataset(trainx_dir, trainy_dir, test_ratio=0.2, random_seed=42):
    """
    将训练数据划分为训练集和测试集

    Args:
        trainx_dir: 原始图像文件夹路径
        trainy_dir: 原始掩码文件夹路径
        test_ratio: 测试集比例，默认0.2（20%）
        random_seed: 随机种子，确保结果可重现
    """

    # 设置随机种子
    random.seed(random_seed)

    # 获取所有图像文件名（不包含扩展名）
    trainx_files = [f for f in os.listdir(trainx_dir) if f.endswith('.bmp')]

    # 提取文件名前缀（去掉扩展名）
    file_prefixes = []
    for file in trainx_files:
        prefix = file.replace('.bmp', '')
        # 检查对应的掩码文件是否存在
        mask_file = f"{prefix}_lesion.bmp"
        if os.path.exists(os.path.join(trainy_dir, mask_file)):
            file_prefixes.append(prefix)

    print(f"找到 {len(file_prefixes)} 对匹配的图像和掩码文件")

    # 随机打乱文件列表
    random.shuffle(file_prefixes)

    # 计算测试集大小
    test_size = int(len(file_prefixes) * test_ratio)
    train_size = len(file_prefixes) - test_size

    print(f"训练集: {train_size} 个文件")
    print(f"测试集: {test_size} 个文件")

    # 分割文件列表
    test_prefixes = file_prefixes[:test_size]
    train_prefixes = file_prefixes[test_size:]

    # 创建目标文件夹
    base_dir = Path(trainx_dir).parent
    testx_dir = base_dir / 'testx'
    testy_dir = base_dir / 'testy'
    new_trainx_dir = base_dir / 'new_trainx'
    new_trainy_dir = base_dir / 'new_trainy'

    # 创建文件夹
    for dir_path in [testx_dir, testy_dir, new_trainx_dir, new_trainy_dir]:
        dir_path.mkdir(exist_ok=True)
        print(f"创建文件夹: {dir_path}")

    # 复制测试集文件
    print("\n正在复制测试集文件...")
    for prefix in test_prefixes:
        # 复制图像文件
        src_img = os.path.join(trainx_dir, f"{prefix}.bmp")
        dst_img = testx_dir / f"{prefix}.bmp"
        shutil.copy2(src_img, dst_img)

        # 复制掩码文件
        src_mask = os.path.join(trainy_dir, f"{prefix}_lesion.bmp")
        dst_mask = testy_dir / f"{prefix}_lesion.bmp"
        shutil.copy2(src_mask, dst_mask)

    # 复制训练集文件
    print("正在复制训练集文件...")
    for prefix in train_prefixes:
        # 复制图像文件
        src_img = os.path.join(trainx_dir, f"{prefix}.bmp")
        dst_img = new_trainx_dir / f"{prefix}.bmp"
        shutil.copy2(src_img, dst_img)

        # 复制掩码文件
        src_mask = os.path.join(trainy_dir, f"{prefix}_lesion.bmp")
        dst_mask = new_trainy_dir / f"{prefix}_lesion.bmp"
        shutil.copy2(src_mask, dst_mask)

    print(f"\n数据划分完成！")
    print(f"测试集图像: {testx_dir} ({len(test_prefixes)} 个文件)")
    print(f"测试集掩码: {testy_dir} ({len(test_prefixes)} 个文件)")
    print(f"训练集图像: {new_trainx_dir} ({len(train_prefixes)} 个文件)")
    print(f"训练集掩码: {new_trainy_dir} ({len(train_prefixes)} 个文件)")

    return {
        'train_files': train_prefixes,
        'test_files': test_prefixes,
        'train_size': len(train_prefixes),
        'test_size': len(test_prefixes)
    }

if __name__ == "__main__":
    # 设置路径
    current_dir = Path(__file__).parent
    trainx_path = current_dir / 'trainx'
    trainy_path = current_dir / 'trainy'

    # 执行数据划分
    result = split_dataset(
        trainx_dir=str(trainx_path),
        trainy_dir=str(trainy_path),
        test_ratio=0.2,  # 20%作为测试集
        random_seed=42   # 固定随机种子确保结果可重现
    )

    print(f"\n划分结果:")
    print(f"- 训练集: {result['train_size']} 对文件")
    print(f"- 测试集: {result['test_size']} 对文件")